const { verifyToken } = require("../utils/jwt");

// This is a TOKEN-type Lambda authorizer. API Gateway invokes it on every
// request to a protected route, BEFORE the actual todos Lambda ever runs.
// It never touches the request body — its only job is: does this bearer
// token prove who the caller is, and should this request be let through.
exports.handler = async (event) => {
  const authHeader = event.authorizationToken || "";
  const token = authHeader.replace(/^Bearer\s+/i, "");

  if (!token) {
    // API Gateway maps a thrown "Unauthorized" to a 401 automatically.
    throw new Error("Unauthorized");
  }

  try {
    const decoded = verifyToken(token);

    // Returning an IAM policy is how a Lambda authorizer communicates its
    // verdict to API Gateway. "Allow" + methodArn lets this exact request
    // continue; anything else is treated as a deny.
    return buildPolicy(decoded.sub, "Allow", event.methodArn, {
      userId: decoded.sub,
    });
  } catch (err) {
    // Invalid signature, malformed token, or expired -> deny.
    // Throwing "Unauthorized" (rather than returning a Deny policy) gives
    // the caller a clean 401 instead of an opaque 500.
    throw new Error("Unauthorized");
  }
};

function buildPolicy(principalId, effect, resource, context) {
  return {
    principalId,
    policyDocument: {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Effect: effect,
          Resource: resource,
        },
      ],
    },
    // `context` is passed through to the downstream Lambda as
    // event.requestContext.authorizer — this is how create/list/get/
    // update/delete know which user is making the request.
    context,
  };
}
