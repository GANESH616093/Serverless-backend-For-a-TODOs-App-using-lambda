const { DeleteCommand, GetCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { ok, notFound, serverError } = require("../../utils/response");

const TABLE = process.env.TODOS_TABLE;

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.userId;
    const todoId = event.pathParameters.id;

    const existing = await ddb.send(
      new GetCommand({ TableName: TABLE, Key: { userId, todoId } })
    );
    if (!existing.Item) {
      return notFound("todo not found");
    }

    await ddb.send(new DeleteCommand({ TableName: TABLE, Key: { userId, todoId } }));

    return ok({ deleted: todoId });
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
