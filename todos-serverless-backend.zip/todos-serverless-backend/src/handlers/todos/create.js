const { v4: uuid } = require("uuid");
const { PutCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { created, badRequest, serverError } = require("../../utils/response");

const TABLE = process.env.TODOS_TABLE;

exports.handler = async (event) => {
  try {
    // Injected by the Lambda authorizer — see src/authorizer/authorizer.js
    const userId = event.requestContext.authorizer.userId;
    const { title, description } = JSON.parse(event.body || "{}");

    if (!title) {
      return badRequest("title is required");
    }

    const now = new Date().toISOString();
    const todo = {
      userId,
      todoId: uuid(),
      title,
      description: description || "",
      completed: false,
      createdAt: now,
      updatedAt: now,
    };

    await ddb.send(new PutCommand({ TableName: TABLE, Item: todo }));

    return created(todo);
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
