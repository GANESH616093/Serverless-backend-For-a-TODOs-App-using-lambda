const { GetCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { ok, notFound, serverError } = require("../../utils/response");

const TABLE = process.env.TODOS_TABLE;

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.userId;
    const todoId = event.pathParameters.id;

    const result = await ddb.send(
      new GetCommand({ TableName: TABLE, Key: { userId, todoId } })
    );

    if (!result.Item) {
      return notFound("todo not found");
    }

    return ok(result.Item);
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
