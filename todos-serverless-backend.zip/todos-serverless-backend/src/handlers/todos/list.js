const { QueryCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { ok, serverError } = require("../../utils/response");

const TABLE = process.env.TODOS_TABLE;

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.userId;

    const result = await ddb.send(
      new QueryCommand({
        TableName: TABLE,
        KeyConditionExpression: "userId = :userId",
        ExpressionAttributeValues: { ":userId": userId },
      })
    );

    const items = (result.Items || []).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    );

    return ok({ items });
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
