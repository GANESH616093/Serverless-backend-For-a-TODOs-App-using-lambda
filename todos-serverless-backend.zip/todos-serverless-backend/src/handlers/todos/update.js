const { GetCommand, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { ok, badRequest, notFound, serverError } = require("../../utils/response");

const TABLE = process.env.TODOS_TABLE;
const ALLOWED_FIELDS = ["title", "description", "completed"];

exports.handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.userId;
    const todoId = event.pathParameters.id;
    const updates = JSON.parse(event.body || "{}");

    const fields = Object.keys(updates).filter((k) => ALLOWED_FIELDS.includes(k));
    if (fields.length === 0) {
      return badRequest("provide at least one of: title, description, completed");
    }

    const existing = await ddb.send(
      new GetCommand({ TableName: TABLE, Key: { userId, todoId } })
    );
    if (!existing.Item) {
      return notFound("todo not found");
    }

    const expressionParts = fields.map((f, i) => `#${f} = :${f}`);
    const names = fields.reduce((acc, f) => ({ ...acc, [`#${f}`]: f }), {});
    const values = fields.reduce((acc, f) => ({ ...acc, [`:${f}`]: updates[f] }), {});

    const result = await ddb.send(
      new UpdateCommand({
        TableName: TABLE,
        Key: { userId, todoId },
        UpdateExpression:
          "SET " + expressionParts.join(", ") + ", updatedAt = :updatedAt",
        ExpressionAttributeNames: names,
        ExpressionAttributeValues: { ...values, ":updatedAt": new Date().toISOString() },
        ReturnValues: "ALL_NEW",
      })
    );

    return ok(result.Attributes);
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
