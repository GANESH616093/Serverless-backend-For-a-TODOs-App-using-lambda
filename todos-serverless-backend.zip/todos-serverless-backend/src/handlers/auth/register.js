const bcrypt = require("bcryptjs");
const { GetCommand, PutCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { signToken } = require("../../utils/jwt");
const { created, badRequest, serverError } = require("../../utils/response");

const TABLE = process.env.USERS_TABLE;

exports.handler = async (event) => {
  try {
    const { name, email, password } = JSON.parse(event.body || "{}");

    if (!name || !email || !password) {
      return badRequest("name, email and password are required");
    }
    if (password.length < 6) {
      return badRequest("password must be at least 6 characters");
    }

    const existing = await ddb.send(
      new GetCommand({ TableName: TABLE, Key: { email: email.toLowerCase() } })
    );
    if (existing.Item) {
      return badRequest("an account with that email already exists");
    }

    const passwordHash = await bcrypt.hash(password, 10);

    await ddb.send(
      new PutCommand({
        TableName: TABLE,
        Item: {
          email: email.toLowerCase(),
          name,
          passwordHash,
          createdAt: new Date().toISOString(),
        },
      })
    );

    const token = signToken({ sub: email.toLowerCase() });

    return created({ token, user: { email: email.toLowerCase(), name } });
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
