const bcrypt = require("bcryptjs");
const { GetCommand } = require("@aws-sdk/lib-dynamodb");
const { ddb } = require("../../utils/dynamodb");
const { signToken } = require("../../utils/jwt");
const { ok, badRequest, unauthorized, serverError } = require("../../utils/response");

const TABLE = process.env.USERS_TABLE;

exports.handler = async (event) => {
  try {
    const { email, password } = JSON.parse(event.body || "{}");

    if (!email || !password) {
      return badRequest("email and password are required");
    }

    const result = await ddb.send(
      new GetCommand({ TableName: TABLE, Key: { email: email.toLowerCase() } })
    );
    const user = result.Item;

    if (!user) {
      return unauthorized("invalid email or password");
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return unauthorized("invalid email or password");
    }

    const token = signToken({ sub: user.email });

    return ok({ token, user: { email: user.email, name: user.name } });
  } catch (err) {
    console.error(err);
    return serverError();
  }
};
