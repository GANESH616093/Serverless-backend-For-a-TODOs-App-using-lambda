function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type,Authorization",
      "Access-Control-Allow-Methods": "OPTIONS,GET,POST,PUT,DELETE",
    },
    body: JSON.stringify(body),
  };
}

const ok = (body) => response(200, body);
const created = (body) => response(201, body);
const badRequest = (message) => response(400, { error: message });
const unauthorized = (message) => response(401, { error: message });
const notFound = (message) => response(404, { error: message });
const serverError = (message) => response(500, { error: message || "Internal server error" });

module.exports = { ok, created, badRequest, unauthorized, notFound, serverError };
