const jwt = require("jsonwebtoken");

const SECRET = process.env.JWT_SECRET;

function signToken(payload) {
  // Token carries the user's email as `sub` and is valid for 7 days.
  return jwt.sign(payload, SECRET, { expiresIn: "7d" });
}

function verifyToken(token) {
  // Throws if invalid or expired — callers should catch this.
  return jwt.verify(token, SECRET);
}

module.exports = { signToken, verifyToken };
